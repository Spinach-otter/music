<template>
  <div id="app">
    <Swiper/>
  </div>
</template>

<script>
import Swiper from './components/Swiper.vue'

export default {
  name: 'App',
  components: {
    Swiper
  }
}
</script>

<style>
body{
  margin:0;
  padding:0;
  background-color:#8E1426
}
</style>
